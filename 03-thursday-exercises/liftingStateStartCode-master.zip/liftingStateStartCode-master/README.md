# Lifting State Start Code

## Important 1! This project is not meant to be cloned.
Download as a zip-file, unzip, and copy files into, either an existing project, or a new create-react-project in the src-folder


## Important 2 Add uuid to your project, like so:
In the **root** of your project (folder with package.json) do:

`npm install uuid react-bootstrap bootstrap` 

or if are using yarn

`yarn add uuid react-bootstrap bootstrap`
